let handler = async (m, { conn }) => {
let fotonya = 'https://telegra.ph/file/53ae11c5a6afda0698cbd.jpg'
let sewa = `Hai Kak, Ingin Donasi?, Silahkan Donasi Ke Payment Yang Ada Di Bawah, Dengan Kamu Berdonasi Berarti Kamu Berkontribusi Dalam Perkembangan Bot Ini..

▧「 *P E M B A Y A R A N* 」

*🎗️E-Walet*
• Ovo = 0831-3812-4277
• Dana = 0838-6213-3750


*🎗️Rekening*
• Mandiri = 
• BTPN Jenius = 

👤A/N : J** S**

Terima Kasih Yang Sudah Donasi, Berapapun Donasi Kamu Akan Sangat Kami Hargain >,<
`
conn.sendFile(m.chat, fotonya, 'anu.jpg', sewa, m)
}
handler.help = ['donasi']
handler.tags = ['main']
handler.command = /^(donasi|donate)$/i

export default handler