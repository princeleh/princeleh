import fs from "fs"
let handler = async (m, { conn }) => {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0]: m.fromMe ? conn.user.jid: m.sender
    if (!(who in global.db.data.users)) return m.reply(`User ${who} not in database`)
    let user = global.db.data.users[who]
    let isMods = global.owner.filter(([number, _, isDeveloper]) => number && isDeveloper).map(([number]) => number).map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(who)
    let isOwner = m.fromMe || isMods || [conn.decodeJid(global.conn.user.id), ...global.owner.filter(([number, _, isDeveloper]) => number && !isDeveloper).map(([number]) => number)].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(who)
    let isPrems =  isOwner || new Date() - user.premiumTime < 0
    let caption = `
${isMods ? '●────━───༺༻───━───●\n🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟\n●────━───༺༻───━───●' : isOwner ? '●────━───༺༻───━───●\n🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟\n●────━───༺༻───━───●' : isPrems ? '●────━───༺༻───━───●\n🌟🌟🌟🌟🌟🌟🌟🌟🌟🌟\n●────━───༺༻───━───●' : user.level > 999 ? 'Elite User' : '●────━───༺༻───━───●'}
┏─────────────────⬣
┆      《 BANK USER 》
┗┬──────────────┈ ⳹
┏┆ 👤 *Name:* ${user.registered ? user.name : conn.getName(m.sender)}
┆┆ 💰 *Money:* Rp.${user.money}
┆┆
┆┆ 🎫 *Atm:* ${user.atm > 0 ? 'Level ' + user.atm : 'Tidak Punya'}
┆┆ 🏦 *Bank:* Rp.${user.bank}
┆┆ 🖨️ *Storage:* Rp.${user.fullatm}
┗──────────────┈ ⳹

⚕️ *Status:*   ${user.premiumTime > 0 ? '👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑' : 'Free'}
●────━───༺༻───━───●
`.trim()
    conn.fakeReply(m.chat, caption, '0@s.whatsapp.net', 'CherlyMD Version 1.4.8', 'status@broadcast')
}
handler.help = ['bank']
handler.tags = ['rpg']
handler.command = /^bank$/i
handler.register = true
handler.group = true
handler.rpg = true

export default handler