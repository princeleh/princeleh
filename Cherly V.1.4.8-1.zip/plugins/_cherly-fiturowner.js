import fs from 'fs'

let handler = async (m, { conn }) => {
	let tqto = `╔「 Feature Owner 」
╎ ⌬ .enable
╎ ⌬ .delesewa
╎ ⌬ .addsewa <hari>
╎ ⌬ .titlein [nama]
╎ ⌬ .bcgcb
╎ ⌬ .listpc
╎ ⌬ .addlimit
╎ ⌬ .addprem [@user] <days>
╎ ⌬ .banchat
╎ ⌬ .ban
╎ ⌬ .block
╎ ⌬ .unblock
╎ ⌬ .broadcast <teks>
╎ ⌬ .bc <teks>
╎ ⌬ .broadcastchats <teks>
╎ ⌬ .bcchats <teks>
╎ ⌬ .broadcastgroup <teks>
╎ ⌬ .bcgc <teks>
╎ ⌬ .clearsession
╎ ⌬ .cleartmp
╎ ⌬ .delprem [@user]
╎ ⌬ .deleteuser
╎ ⌬ .df
╎ ⌬ .email
╎ ⌬ >
╎ ⌬ =>
╎ ⌬ $ [Exec]
╎ ⌬ .gcemail
╎ ⌬ .getdb
╎ ⌬ .getfile
╎ ⌬ .getname <@tag/reply>
╎ ⌬ .getsessi
╎ ⌬ .getplugin <text>
╎ ⌬ .ojoin <chat.whatsapp.com>
╎ ⌬ .okick @user
╎ ⌬ .leavegc
╎ ⌬ .out
╎ ⌬ .ohidetag <teks>
╎ ⌬ .opromote @tag
╎ ⌬ .resetchat
╎ ⌬ .resetlimit
╎ ⌬ .resetprefix
╎ ⌬ .resetuser
╎ ⌬ .restart
╎ ⌬ .rf <old name> | <new name>
╎ ⌬ .renamefile <old name> | <new name>
╎ ⌬ .setbotbio
╎ ⌬ .setmenu <teks>
╎ ⌬ .setmenubefore <teks>
╎ ⌬ .setmenuheader <teks>
╎ ⌬ .setmenubody <teks>
╎ ⌬ .setmenufooter <teks>
╎ ⌬ .setmenuafter <teks>
╎ ⌬ .setppbot
╎ ⌬ .sf <teks>
╎ ⌬ .unbanchat
╎ ⌬ .unban
╎ ⌬ .unwarn @mention
╎ ⌬ .warn @tag
╎ ⌬ .self
╎ ⌬ .public
╚━━━━━━━━◉
`;
	await conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/e718a2420344e1872527e.jpg' }, caption: tqto }, m)
}
handler.help = ['fiturowner']
handler.tags = ['cherlymenu']
handler.command = /^(menuowner|menu_owner)$/i;

export default handler;
